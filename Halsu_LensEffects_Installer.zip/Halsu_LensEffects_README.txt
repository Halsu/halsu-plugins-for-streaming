# Halsu LensEffects

## Installation

1. Close OBS Studio if it's running
2. Extract this ZIP file
3. Copy the contents to your OBS installation folder:
   - Windows: C:\Program Files\obs-studio\
   - The folder structure should merge with existing folders

## Files Included

- obs-plugins/64bit/Halsu_LensEffects.dll
- data/obs-plugins/Halsu_LensEffects/Halsu_LensEffects.effect

## Usage

1. Open OBS Studio
2. Right-click on a video source → Filters
3. Click "+" → Effect Filters → "Halsu LensEffects"

## Uninstall

Delete these files from your OBS installation:
- obs-plugins/64bit/Halsu_LensEffects.dll
- data/obs-plugins/Halsu_LensEffects/ (entire folder)
