# Halsu HybridKeyer
*A 3rd-party keying solution for OBS Studio.*

## Installation
1. Extract the ZIP file
2. Copy `obs-plugins/64bit/Halsu_HybridKeyer.dll` to:
   `C:/Program Files/obs-studio/obs-plugins/64bit/`
3. Copy the `data` folder to:
   `C:/Program Files/obs-studio/`

## Usage
* Open OBS Studio
* Right-click a source -> **Filters**
* Click **+** -> **Halsu HybridKeyer**

## Support
If you encounter any issues or have feature suggestions, please [open an issue](https://github.com/Halsu/halsu-plugins-for-streaming/issues) on GitHub.

## AI Disclosure & Licensing
* **Licensing**: This plugin is licensed under GPL v2.0. Source code is available [on GitHub](https://github.com/Halsu/halsu-plugin-factories).
* **AI Disclaimer**: This resource was developed as a hybrid of human expertise and AI assistance. While the core project and original shader logic were hand-coded by Halsu, AI tools (including Antigravity) were utilized to implement specific shader features, generate C++ boilerplate, and develop the build infrastructure.
* **Affiliation**: This is a third-party plugin. It is not affiliated with, or an official part of, the OBS Project.
