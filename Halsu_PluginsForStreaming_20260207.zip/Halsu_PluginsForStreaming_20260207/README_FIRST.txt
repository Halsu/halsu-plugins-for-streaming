# Halsu Plugins for Streaming - Combined Installer
Version: 20260207

This package contains the following OBS Studio plugins:
- Halsu AlphaTools (Restored Release Version)
- Halsu HybridKeyer (Stable Version)
- Halsu Relightwrap (v0.3.2 Fix)

## Installation

1. Close OBS Studio if it's running.
2. Extract this ZIP file.
3. Copy the 'data' and 'obs-plugins' folders to your OBS installation directory:
   - Typically: C:\Program Files\obs-studio\
4. When prompted, Choose "Replace the files in the destination" or "Merge".

## Included Plugins

### Halsu AlphaTools
Advanced alpha channel manipulation and edge refinement.

### Halsu HybridKeyer
High-quality green/blue screen keyer with luma-normalized difference engine.

### Halsu Relightwrap
Advanced lightwrapping with erosion-based defringing and directional relighting.

## License
All plugins are released under the GPL v2.0 License.
Source code is available at: https://github.com/halsu/halsu-plugins-for-streaming
